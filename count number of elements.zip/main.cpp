//count thge number of elements in an array
#include<iostream>
using namespace std;
int main(){
    int arr[]={34,56,78,67,43};
    int count= sizeof(arr)/sizeof (arr[0]);
    cout<<"Number of elements in an array:"<<count<<endl;
    return 0;
}