#include <iostream>
using namespace std;
int main()
{
    int n,i,j,temp;
    cout<<"Enter the number of elements:";
    cin>>n;
    
    int arr[100];
    cout<<"Enter"<<" "<<n<<" "<<"elements:";
    
    for(i=0;i<n;i++){
        cin>>arr[i];
    }
    
    
    //bubble sort Traversing
    for(i=0;i<n-1;i++){
        cout<<"\nPass"<<i+1<<" : "<<endl;
    } 
    for(j=0;j<n-i-1;j++){
        cout<<"Comparing"<<arr[j]<<"and"<<arr[j+1]<<endl;
        
        
        if(arr[j]>arr[j+1]){
            temp=arr[j];
            arr[j]=arr[j+1];
            arr[j+1]=temp;
            
            cout<<"Swapping to:";
            
            for(int k=0;k<n;k++){
            cout<<arr[k]<<" ";
        }
    }
}
cout<<"Sorted array :";
for(int i=0;i<n;i++){
    cout<<arr[i]<<" ";
}
return 0;
}
