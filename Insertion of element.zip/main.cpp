#include<iostream>
using namespace std;
int main()
{
    int a[8]={22,33,44,55,66,77,88};
    int N=7;
    int k=3;
    int ITEM=35;
    
    for(int J=N;J>=k;J--)
    {
        a[J+1]=a[J];
    }
    a[k]=ITEM;
    N=N+1;
    cout<<"Array after insertion :";
    for(int i=1;i<N;i++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;
    return 0;
}