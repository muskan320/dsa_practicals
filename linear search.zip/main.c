#include <stdio.h>

int main() {
    int a[100], n, data, i, found = 0;

    // Input number of elements
    printf("Enter number of elements: ");
    scanf("%d", &n);

    // Input elements
    printf("Enter %d elements:\n", n);
    for(i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }

    // Input the data to search
    printf("Enter the element to search: ");
    scanf("%d", &data);

    // Linear Search
    for(i = 0; i < n; i++) {
        if(a[i] == data) {
            printf("Element found at index: %d\n", i);  // or i+1 for position
            found = 1;
            break;
        }
    }

    // If not found
    if(found == 0) {
        printf("Element not found\n");
    }

    return 0;
}                                                                                                                                                                                                