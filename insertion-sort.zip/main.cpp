//Practical 5: WAP TO IMPLEMENT INSERTION SORT TO SORT A GIVEN LIST OF INTEGERS IN ASCENDING ORDER.

#include<iostream>
using namespace std;
int main()
{
    int n;
    cout<<"Enter the number of elements in an array : ";
    cin>>n;
    
    int arr[100];
    cout<<"Enter"<< " "<<n<<" "<<"element";
    for( int i=0;i<n;i++){
        cin>>arr[i];
    }
    
    //insertion SORT
    for( int i=1;i<n;i++){
        int key = arr[i];
        int j=i-1;
        while(j>=0 && arr[j]>key){
            arr[j+1]=arr[j];
            j--;
            
        }
        arr[j+1]=key;
        
    }
    
    cout<<"sorted array(ascending)";
     for( int i=0;i<n;i++){
        cout<<arr[i]<<" ";
     }
     cout<<endl;
     return 0;
}