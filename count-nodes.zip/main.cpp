#include<iostream>
using namespace std;
struct Node{
    int data;
    Node*next;
};

int countNodes(Node*head){
    int count=0;
    Node*current = head;
    while(current!=nullptr){
        count++;
        current = current->next;
    }
    return count;
    }

void insertEnd(Node*& head, int value){
    Node*newNode = new Node{value,nullptr};
    
    if(head == nullptr){
        head = newNode;
        return;
    }
    Node*temp = head;
    while(temp->next !=nullptr){
        temp =temp->next;
    }
    temp->next = newNode;
    }
     
    int main(){
        Node*head = nullptr;
        
        insertEnd(head,10);
        insertEnd(head,20);
        insertEnd(head,30);
        insertEnd(head,40);
        
        cout<<"Number of elements in linked list="<<countNodes(head)<<endl;
        return 0;
    }

