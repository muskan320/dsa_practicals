//count number of elements in an array 
#include<iostream>
using namespace std;
int main(){
    int a[100],n,i;
    cout<<"enter number of elements:";
    cin>>n;
    cout<<"Enter"<<" "<<n<<" "<<"elements:";
    for (i+0;i<n;i++)
{
    cin>>a[i];
}
cout<<"Total number of elements in an array is:"<<n<<endl;
return 0;
}
