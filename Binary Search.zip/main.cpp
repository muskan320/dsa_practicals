#include<iostream>
using namespace std;
int BinarySearch(int arr[],int n,int key){
    int low = 0,high =n-1;
    
    while(low<=high)
    {
        int mid=(low+high)/2;
        if(arr[mid]==key)
        return mid;
        else if(arr[mid]<key)
        low =mid+1;
        else
        high=mid-1;
    }
    return-1;
}
int main()
{
    int n,key;
    cout<<"enter the number of elements:";
    cin>>n;
    
    int arr[n];
    cout<<"Enter"<<" "<<n<<" "<<"elements in a ** sorted order **:\n";
    
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
        
    }
    cout<<"Enter the element to be search :";
    cin>>key;
    
    int result =BinarySearch(arr,n,key);
    
    if (result!=-1)
    cout<<"Element found at index :"<<result<<endl;
    
    else
    cout<<"Element not found"<<endl;
    return 0;
}
    
    
